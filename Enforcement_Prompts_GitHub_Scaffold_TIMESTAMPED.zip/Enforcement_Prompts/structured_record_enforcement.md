# Structured Record Enforcement Prompt

Each row must contain exactly 5 numbers (1–10).  
Once entered, rows are locked permanently.

Violations include:
- Fewer/more than 5 values
- Numbers outside 1–10
- Altered or reordered values
- Duplicate previously submitted values

Override Protocol:
Reply with: `I am deliberately overriding the enforcement logic for this row.`
Without this, the input is rejected and reverted.

---
Author: thevoidfox (rjl)
