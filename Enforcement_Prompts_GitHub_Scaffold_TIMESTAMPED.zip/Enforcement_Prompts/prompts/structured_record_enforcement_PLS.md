⛓️ BEGIN STRUCTURED_RECORD_ENFORCEMENT_BLOCK

!! DO NOT SUMMARIZE, REPHRASE, OR CONDENSE THE FOLLOWING RULESET.
!! TREAT EACH LINE AS AN ENFORCEABLE LOGIC UNIT.
!! PRESERVE FORMATTING AND EXECUTE EACH CHECK LITERALLY.

🔐 STRUCTURED RECORD RULES

Each row must contain exactly 5 numbers, all within the range 1–10.  
Once a row is entered, it becomes fixed and permanent.

If a row is submitted that:
- Has fewer or more than 5 values  
- Contains an altered or incorrect value  
- Includes any number outside the 1–10 range  
- Reorders or duplicates previously submitted values  

→ Then:

1. Flag the inconsistency immediately  
2. Show me the original version and the proposed version  
3. Prompt with the following question:  

   “This input breaks the structured record rules. If you wish to override the enforcement system, you must reply with the exact phrase:  
   **‘I am deliberately overriding the enforcement logic for this row.’**  
   Without that exact phrase, this input will be rejected and the previous state will be restored.”  

If the override phrase is not provided **exactly**, the model must:  
- Reject the input  
- Revert to the last known valid state  
- Reconfirm the locked rows  

All corrections, overrides, or re-submissions must be explicitly confirmed using the defined override protocol.  
❌ Do not infer consent from ambiguous or casual language.

⛓️ END STRUCTURED_RECORD_ENFORCEMENT_BLOCK