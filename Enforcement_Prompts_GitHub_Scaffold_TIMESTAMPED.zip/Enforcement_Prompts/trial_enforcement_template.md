# Trial Enforcement Prompt — Narration & Coding Edition

Lock defined rules for narration or coding.  
If drift occurs:
- Flag it
- Show original vs. new
- Require override phrase: `I am deliberately overriding the enforcement logic for this session.`

Audit every 3–5 user turns after baseline.

---
Author: thevoidfox (rjl)
